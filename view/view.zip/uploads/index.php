<?php

header('Location: https://developforweb.com.br/agendamento');
